from cronotipy import cronotipy

cronotipy.runGUI()
